﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Xml.Linq;

namespace KeyboardSequenceTester
{
    /// <summary>
    /// Logique d'interaction pour MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private SolidColorBrush failColor = new SolidColorBrush(Color.FromRgb(255, 0, 0));

        private SolidColorBrush successColor = new SolidColorBrush(Color.FromRgb(0, 255, 0));

        private XDocument xmlSequences;

        private List<Sequence> allSequences = new List<Sequence>();

        private Sequence selectedSequence;

        private int sequenceIndex = 0;

        private Stopwatch timeWatcher;

        private bool exactMode = false;

        private bool keyDownMode = false;

        private string ResourcesFolder = System.AppDomain.CurrentDomain.BaseDirectory + "Resources\\";

        private string IconsFolder = System.AppDomain.CurrentDomain.BaseDirectory + "Resources\\icons\\";

        /// <summary>
        /// 
        /// </summary>
        public MainWindow()
        {
            //
            InitializeComponent();

            //
            OnLoad();

            //
            this.PreviewKeyDown += MainWindow_KeyEventControl;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainWindow_KeyEventControl(object sender, KeyEventArgs e)
        {
            //System.Console.WriteLine("Keyboard.Modifiers : " + Keyboard.Modifiers);
            if (e.Key == Key.Space && Keyboard.Modifiers == 0)
            {
                if (timeWatcher != null && timeWatcher.IsRunning) stopSequence();
                else startSequence();
            }
        }




        /// <summary>
        /// 
        /// </summary>
        private void OnLoad()
        {
            try
            {
                xmlSequences = XDocument.Load(ResourcesFolder + "sequences.xml");

                var skillsList = (from key in xmlSequences.Descendants("skill")
                                  select new Skill()
                                      {
                                          Name = key.Attribute("name").Value,
                                          Icon = key.Attribute("icon") != null ? key.Attribute("icon").Value : "no_icon.png",
                                          Shortcut = key.Attribute("shortcut").Value,
                                          CastingTime = ConvertToDouble(key.Attribute("shortcut").Value)
                                      }).ToList<Skill>();

                var sequencesNames = (from key in xmlSequences.Descendants("sequence") select key.Attribute("name").Value).ToList();

                allSequences = (from key in xmlSequences.Descendants("sequence")
                                select new Sequence()
                                        {
                                            Name = key.Attribute("name").Value,
                                            Timer = ConvertToDouble(key.Attribute("timer").Value),
                                            Icon = key.Attribute("icon") != null ? key.Attribute("icon").Value : "no_icon.png",

                                            Skills = (
                                                from seqSkill in ( ( from subkey in key.Descendants("key") select subkey.Attribute("skill").Value).ToList() )
                                                join eSkill in skillsList
                                                on seqSkill equals eSkill.Name
                                                select eSkill).ToList<Skill>()

                                        }
                               ).ToList<Sequence>();
                
                

                if (sequencesNames.Count > 0)
                {
                    this.SequencesComboBox.SelectionChanged += SequencesComboBox_SelectionChanged;
                    this.SequencesComboBox.ItemsSource = sequencesNames;
                }

            }
            catch (Exception e)
            {
                System.Console.WriteLine("Exception : " + e.Message);
                //throw e;
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Value"></param>
        /// <returns></returns>
        public static double ConvertToDouble(string Value)
        {
            if (Value == null)
            {
                return 0;
            }
            else
            {
                double OutVal;
                double.TryParse(Value, out OutVal);

                if (double.IsNaN(OutVal) || double.IsInfinity(OutVal))
                {
                    return 0;
                }
                return OutVal;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SequencesComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //
            if (timeWatcher != null && timeWatcher.IsRunning) stopSequence();

            selectedSequence = allSequences.Where(s => s.Name == SequencesComboBox.SelectedValue.ToString()).FirstOrDefault();

            if (selectedSequence != null)
            {
                SequenceIcon.Source = new BitmapImage(new Uri(IconsFolder + selectedSequence.Icon));
                UpdateNextIcon(0);
            }
            /*
            System.Console.WriteLine("SequenceIcon.Source : " + SequenceIcon.Source);
            System.Console.WriteLine("ImageKeyIcon.Source: " + ImageKeyIcon.Source);
            System.Console.WriteLine("ImageNextKeyIcon.Source : " + ImageNextKeyIcon.Source);
            */
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            if (selectedSequence == null) return;

            if (StartButton.Content.ToString() == "Start")
            {
                startSequence();
            }
            else
            {
                stopSequence();
            }
        }


        /// <summary>
        /// 
        /// </summary>
        private void startSequence()
        {
            sequenceIndex = 0;

            SetBarProgress(0);

            timeWatcher = new Stopwatch();
            timeWatcher.Start();
            StartButton.Content = "Stop";


            if (keyDownMode)
            {
                this.KeyDown += MainWindow_KeyEvent;
                this.MouseDown += MainWindow_MouseEvent;
            }
            else
            {
                this.KeyUp += MainWindow_KeyEvent;
                this.MouseUp += MainWindow_MouseEvent;
            }

            this.pnlTextBox2.Text = String.Format("Starting sequence {0} - {1} key(s) expected", selectedSequence.Name, selectedSequence.Skills.Count);

            this.pnlTextBox2.IsEnabled = false;

            //desactivate combobox
            this.SequencesComboBox.SelectionChanged -= SequencesComboBox_SelectionChanged;

            UpdateNextIcon(sequenceIndex);
        }

        /// <summary>
        /// 
        /// </summary>
        private void stopSequence()
        {
            timeWatcher.Stop();
            StartButton.Content = "Start";

            this.KeyDown -= MainWindow_KeyEvent;
            this.MouseDown -= MainWindow_MouseEvent;

            this.KeyUp -= MainWindow_KeyEvent;
            this.MouseUp -= MainWindow_MouseEvent;

            this.pnlTextBox2.IsEnabled = true;
            //active the combobox
            this.SequencesComboBox.SelectionChanged += SequencesComboBox_SelectionChanged;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="value"></param>
        private void SetBarProgress(double percent)
        {
            //System.Console.WriteLine("SetBarProgress : " + percent + "%");
            //System.Console.WriteLine("SequenceProgress_Background.Width : " + SequenceProgress_Background.Width.ToString());

            double newValue = (SequenceProgress.Width * (percent / 100));
            SequenceProgress_Bar.Width = newValue;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainWindow_KeyEvent(object sender, KeyEventArgs e)
        {
            /*
            System.Console.WriteLine("=====================================");
            System.Console.WriteLine("e.Key : " + e.Key.ToString());
            System.Console.WriteLine("e.KeyboardDevice : " + e.KeyboardDevice);
            System.Console.WriteLine("e.KeyStates : " + e.KeyStates);
            System.Console.WriteLine("e.SystemKey : " + e.SystemKey);
            //if (e.KeyboardDevice)
            //System.Console.WriteLine("e.Key : " + e.Key.ToString());
            */
            var lowerRealKey = e.Key.ToString().ToLower();
            var lowerSystemKey = e.SystemKey.ToString().ToLower();
            
            /*
            System.Console.WriteLine("lowerRealKey : " + lowerRealKey);
            System.Console.WriteLine("lowerSystemKey : " + lowerSystemKey);
            */

            //ALT+x
            if (lowerRealKey == "system")
            {
                //only ALT+modifier, don't need to go further
                if (lowerSystemKey.IndexOf("ctrl") > -1 || lowerSystemKey.IndexOf("alt") > -1 || lowerSystemKey.IndexOf("shift") > -1)
                {
                    return;
                }
            }

            //only modifier key pressed => return 
            if (lowerRealKey.IndexOf("ctrl") > -1 || lowerRealKey.IndexOf("alt") > -1 || lowerRealKey.IndexOf("shift") > -1)
            {
                return;
            }

            var input = "";

            if (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl))
            {
                input = "Ctrl+";
            }

            if (Keyboard.IsKeyDown(Key.LeftAlt) || Keyboard.IsKeyDown(Key.RightAlt) || Keyboard.IsKeyDown(Key.System))
            {
                input = input + "Alt+";
            }

            if (Keyboard.IsKeyDown(Key.LeftShift) || Keyboard.IsKeyDown(Key.RightShift))
            {
                input = input + "Shift+";
            }

            //
            if (lowerRealKey == "system")
            {
                input = input + e.SystemKey.ToString();
            }
            else
            {
                input = input + e.Key.ToString();
            }

            //
            if (input != "")
            {
                double timeStamp = timeWatcher.Elapsed.TotalSeconds;
                pnlTextBox2.Text = String.Format("{0:0.00}", timeStamp) + " : " + input + "\n" + pnlTextBox2.Text;
            }

            checkInput(input);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainWindow_MouseEvent(object sender, MouseButtonEventArgs e)
        {

            var input = "";
            if (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl))
            {
                input = "Ctrl+";
            }

            if (Keyboard.IsKeyDown(Key.LeftAlt) || Keyboard.IsKeyDown(Key.RightAlt))
            {
                input = input + "Alt+";
            }

            if (Keyboard.IsKeyDown(Key.LeftShift) || Keyboard.IsKeyDown(Key.RightShift))
            {
                input = input + "Shift+";
            }

            double timeStamp = timeWatcher.Elapsed.TotalSeconds;

            input = input + e.ChangedButton.ToString() + "Clic";

            //System.Console.WriteLine("pnlMainGrid_MouseUp : " + timeStamp.ToString() + " : " + input);
            pnlTextBox2.Text = String.Format("{0:0.00}", timeStamp) + " : " + input + "\n" + pnlTextBox2.Text;

            checkInput(input);

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="input"></param>
        private void checkInput(string input)
        {
            if (String.IsNullOrEmpty(input)) return;
            var refInput = selectedSequence.Skills[sequenceIndex].Shortcut.ToLower();
            input = input.ToLower();

            if (refInput == input)
            {
                sequenceIndex++;
                double percent = (double)sequenceIndex / (double)selectedSequence.Skills.Count * 100;
                percent = Math.Truncate(percent * 100) / 100;
                //System.Console.WriteLine("percent : " + percent);
                SetBarProgress(percent);


                if (sequenceIndex == selectedSequence.Skills.Count)
                {
                    showResults();
                    stopSequence();
                }
                else
                {
                    UpdateNextIcon(sequenceIndex);
                }

                if (timeWatcher.Elapsed.TotalSeconds > selectedSequence.Timer)
                {
                    this.SequenceProgress_Bar.Fill = failColor;
                }
                else
                {
                    this.SequenceProgress_Bar.Fill = successColor;
                }
            }
            else
            {
                //bad input in exact mode = fail
                if (exactMode)
                {
                    this.SequenceProgress_Bar.Fill = failColor;
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        private void showResults()
        {
            NextKeyLabel.Content = "Sequence Ended!";
            pnlTextBox2.Text = "Sequence completed in : " + String.Format("{0:0.00} seconds", timeWatcher.Elapsed.TotalSeconds) + "\n" + pnlTextBox2.Text;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CheckBoxExact_Changed(object sender, RoutedEventArgs e)
        {
            exactMode = CheckBoxExact.IsChecked.Value;
        }

        private void CheckBoxKeyDown_Changed(object sender, RoutedEventArgs e)
        {
            keyDownMode = CheckBoxKeyDown.IsChecked.Value;
        }

        //
        private void UpdateNextIcon(int index)
        {

            NextKeyLabel.Content = selectedSequence.Skills[index].Shortcut + String.Format(" - ({0})", selectedSequence.Skills.Count > index + 1 ? selectedSequence.Skills[index + 1].Shortcut : "");
            ImageKeyIcon.Source = new BitmapImage(new Uri(IconsFolder + selectedSequence.Skills[index].Icon));
            if (selectedSequence.Skills.Count > index + 1)
            {
                ImageNextKeyIcon.Source = new BitmapImage(new Uri(IconsFolder + selectedSequence.Skills[index + 1].Icon));
            }
            else
            {
                ImageNextKeyIcon.Source = new BitmapImage(new Uri(IconsFolder + "no_icon.png"));
            } 

        }


    }

    
    /// <summary>
    /// 
    /// </summary>
    public class Sequence
    {
        public Sequence()
        {
            Skills = new List<Skill>();
        }

        public string Name { get; set; }
        public string Icon { get; set; }
        public double Timer { get; set; }
        public List<Skill> Skills { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    public class SequenceKey
    {
        public SequenceKey()
        {
        }

        public string Name { get; set; }
        public string Icon { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    public class Skill
    {
        public Skill()
        {
        }
        public string Name { get; set; }
        public string Icon { get; set; }
        public string Shortcut { get; set; }
        public double CastingTime{ get; set; }
    }

}
